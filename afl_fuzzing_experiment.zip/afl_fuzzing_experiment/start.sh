#!/bin/bash

bash ./node1/scripts/shell_test.sh > ./node1/track.log
bash ./node2/scripts/shell_test.sh > ./node2/track.log
bash ./node3/scripts/shell_test.sh > ./node3/track.log
bash ./node4/scripts/shell_test.sh > ./node4/track.log
bash ./node5/scripts/shell_test.sh > ./node5/track.log
bash ./node6/scripts/shell_test.sh > ./node6/track.log
bash ./node7/scripts/shell_test.sh > ./node7/track.log
bash ./node8/scripts/shell_test.sh > ./node8/track.log
bash ./node9/scripts/shell_test.sh > ./node9/track.log
bash ./node10/scripts/shell_test.sh > ./node10/track.log