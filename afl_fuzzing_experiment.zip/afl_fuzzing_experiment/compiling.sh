#!/bin/bash

python ./node1/scripts/auto_compiling.python
python ./node2/scripts/auto_compiling.python
python ./node3/scripts/auto_compiling.python
python ./node4/scripts/auto_compiling.python
python ./node5/scripts/auto_compiling.python
python ./node6/scripts/auto_compiling.python
python ./node7/scripts/auto_compiling.python
python ./node8/scripts/auto_compiling.python
python ./node9/scripts/auto_compiling.python
python ./node10/scripts/auto_compiling.python
